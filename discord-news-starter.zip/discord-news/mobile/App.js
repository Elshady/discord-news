import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, FlatList, Image, Linking, Pressable, RefreshControl,
  SafeAreaView, StatusBar, StyleSheet, Text, TextInput, View
} from 'react-native';
import { StatusBar as ExpoStatusBar } from 'expo-status-bar';

const API = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000';
const C = {
  bg: '#101116', panel: '#191B24', panel2: '#20232E', line: '#2B2E3A',
  text: '#F4F5FA', muted: '#9298A8', purple: '#5865F2', purpleSoft: '#252B58',
  green: '#57D6A0'
};

function timeAgo(value) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

function AnnouncementCard({ item, onSave }) {
  return (
    <View style={s.card}>
      <View style={s.cardTop}>
        <View style={s.serverIcon}><Text style={s.serverInitial}>{(item.guildName || 'D')[0].toUpperCase()}</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={s.serverName} numberOfLines={1}>{item.guildName}</Text>
          <Text style={s.meta}>#{item.channelName} · {timeAgo(item.createdAt)}</Text>
        </View>
        <Pressable onPress={() => onSave(item)} hitSlop={10} style={s.saveButton}>
          <Text style={s.saveIcon}>{item.saved ? '★' : '☆'}</Text>
        </Pressable>
      </View>
      <Text style={s.author}>Posted by {item.author}</Text>
      {!!item.content && <Text style={s.message}>{item.content}</Text>}
      {!!item.imageUrl && <Image source={{ uri: item.imageUrl }} style={s.attachment} resizeMode="cover" />}
      <View style={s.cardBottom}>
        <Pressable style={s.openLink} onPress={() => Linking.openURL(item.messageUrl)}>
          <Text style={s.openLinkText}>↗  Open original Discord message</Text>
        </Pressable>
        <Text style={s.linkLabel}>LINKS OPEN IN DISCORD</Text>
      </View>
    </View>
  );
}

export default function App() {
  const [servers, setServers] = useState([]);
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState('all');
  const [tab, setTab] = useState('news');
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true); else setLoading(true);
    setError('');
    try {
      const [serverRes, newsRes] = await Promise.all([
        fetch(`${API}/api/servers`),
        fetch(`${API}/api/announcements?serverId=${filter}&saved=${tab === 'saved'}&q=${encodeURIComponent(query)}`)
      ]);
      if (!serverRes.ok || !newsRes.ok) throw new Error('The news service returned an error.');
      setServers(await serverRes.json());
      setItems(await newsRes.json());
    } catch (e) {
      setError(`Can't reach the Discord News server. Check your API URL and backend. (${e.message})`);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [filter, tab, query]);

  useEffect(() => { load(); }, [load]);

  const toggleSave = async item => {
    const next = !item.saved;
    setItems(current => current.map(x => x.id === item.id ? { ...x, saved: next } : x));
    try {
      await fetch(`${API}/api/announcements/${item.id}/save`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ saved: next })
      });
    } catch { load(); }
  };

  const title = tab === 'saved' ? 'Saved' : 'Your feed';
  return (
    <SafeAreaView style={s.safe}>
      <ExpoStatusBar style="light" />
      <StatusBar barStyle="light-content" backgroundColor={C.bg} />
      <View style={s.header}>
        <View style={s.brandRow}>
          <View style={s.brandMark}><Text style={s.brandMarkText}>N</Text></View>
          <View style={{ flex: 1 }}>
            <Text style={s.brand}>DISCORD <Text style={{ color: C.purple }}>NEWS</Text></Text>
            <Text style={s.tagline}>YOUR SERVERS. ONE FEED.</Text>
          </View>
          <View style={s.live}><View style={s.liveDot}/><Text style={s.liveText}>FEED</Text></View>
        </View>
        <Text style={s.heading}>{title}</Text>
        <Text style={s.subheading}>The latest announcements from your communities.</Text>
        <View style={s.search}>
          <Text style={{ color: C.muted, fontSize: 17 }}>⌕</Text>
          <TextInput value={query} onChangeText={setQuery} placeholder="Search announcements..." placeholderTextColor={C.muted} style={s.searchInput} returnKeyType="search"/>
          {!!query && <Pressable onPress={() => setQuery('')}><Text style={{ color: C.muted }}>✕</Text></Pressable>}
        </View>
      </View>

      <View style={s.filterWrap}>
        <FlatList horizontal showsHorizontalScrollIndicator={false} data={[{ id: 'all', name: 'All servers' }, ...servers]}
          keyExtractor={x => x.id} contentContainerStyle={{ paddingHorizontal: 18, gap: 8 }}
          renderItem={({ item }) => (
            <Pressable onPress={() => setFilter(item.id)} style={[s.chip, filter === item.id && s.chipActive]}>
              <Text style={[s.chipText, filter === item.id && s.chipTextActive]}>{item.name}</Text>
            </Pressable>
          )}/>
      </View>

      {loading ? <View style={s.center}><ActivityIndicator color={C.purple} size="large"/><Text style={s.emptyText}>Loading your news...</Text></View> :
        error ? <View style={s.center}><Text style={s.emptyTitle}>Connection needed</Text><Text style={s.emptyText}>{error}</Text><Pressable style={s.retry} onPress={() => load()}><Text style={s.retryText}>Try again</Text></Pressable></View> :
        <FlatList data={items} keyExtractor={x => x.id} renderItem={({ item }) => <AnnouncementCard item={item} onSave={toggleSave}/>}
          contentContainerStyle={items.length ? s.list : s.emptyList}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor={C.purple}/>}
          ListEmptyComponent={<View style={s.center}><Text style={s.emptyTitle}>Nothing in the feed yet</Text><Text style={s.emptyText}>When your bot sees a message in a connected announcement channel, it will appear here.</Text></View>}/>}
      />

      <View style={s.bottomNav}>
        <Pressable onPress={() => setTab('news')} style={s.navItem}><Text style={[s.navIcon, tab === 'news' && s.navSelected]}>▤</Text><Text style={[s.navText, tab === 'news' && s.navSelected]}>News</Text></Pressable>
        <Pressable onPress={() => setTab('saved')} style={s.navItem}><Text style={[s.navIcon, tab === 'saved' && s.navSelected]}>☆</Text><Text style={[s.navText, tab === 'saved' && s.navSelected]}>Saved</Text></Pressable>
        <Pressable onPress={() => load(true)} style={s.navItem}><Text style={s.navIcon}>↻</Text><Text style={s.navText}>Refresh</Text></Pressable>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: { paddingHorizontal: 20, paddingTop: 12, paddingBottom: 16 },
  brandRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 25 },
  brandMark: { width: 38, height: 38, borderRadius: 12, backgroundColor: C.purple, alignItems: 'center', justifyContent: 'center', marginRight: 11 },
  brandMarkText: { color: 'white', fontWeight: '900', fontSize: 20 },
  brand: { color: C.text, fontWeight: '900', fontSize: 15, letterSpacing: 1.1 },
  tagline: { color: C.muted, fontSize: 9, letterSpacing: 1.5, marginTop: 3 },
  live: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.panel2, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 20, gap: 6 },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: C.green },
  liveText: { color: C.green, fontWeight: '800', fontSize: 9, letterSpacing: 1 },
  heading: { color: C.text, fontSize: 29, fontWeight: '800', letterSpacing: -0.7 },
  subheading: { color: C.muted, fontSize: 13, marginTop: 5, marginBottom: 17 },
  search: { height: 46, borderRadius: 13, backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 10 },
  searchInput: { flex: 1, color: C.text, fontSize: 13 },
  filterWrap: { paddingBottom: 15 },
  chip: { backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8 },
  chipActive: { backgroundColor: C.purpleSoft, borderColor: C.purple },
  chipText: { color: C.muted, fontSize: 12, fontWeight: '600' },
  chipTextActive: { color: '#DDE0FF' },
  list: { paddingHorizontal: 16, paddingBottom: 20, gap: 12 },
  card: { backgroundColor: C.panel, borderRadius: 17, borderWidth: 1, borderColor: C.line, padding: 15 },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  serverIcon: { width: 37, height: 37, borderRadius: 13, backgroundColor: C.purpleSoft, alignItems: 'center', justifyContent: 'center' },
  serverInitial: { color: '#C9CDFF', fontSize: 15, fontWeight: '800' },
  serverName: { color: C.text, fontSize: 13, fontWeight: '800' },
  meta: { color: C.muted, fontSize: 11, marginTop: 3 },
  saveButton: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  saveIcon: { color: '#F2C96D', fontSize: 24 },
  author: { color: C.muted, fontSize: 11, marginTop: 14, marginBottom: 7 },
  message: { color: '#E7E8EF', fontSize: 14, lineHeight: 21 },
  attachment: { width: '100%', height: 180, borderRadius: 11, marginTop: 12, backgroundColor: C.panel2 },
  cardBottom: { borderTopWidth: 1, borderTopColor: C.line, marginTop: 14, paddingTop: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 7 },
  openLink: { backgroundColor: C.purpleSoft, borderRadius: 9, paddingHorizontal: 11, paddingVertical: 9 },
  openLinkText: { color: '#DDE0FF', fontSize: 11, fontWeight: '700' },
  linkLabel: { color: C.muted, fontSize: 8, letterSpacing: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 30, gap: 12 },
  emptyList: { flexGrow: 1, justifyContent: 'center' },
  emptyTitle: { color: C.text, fontSize: 18, fontWeight: '800', textAlign: 'center' },
  emptyText: { color: C.muted, fontSize: 13, lineHeight: 20, textAlign: 'center' },
  retry: { backgroundColor: C.purple, borderRadius: 10, paddingHorizontal: 18, paddingVertical: 11, marginTop: 5 },
  retryText: { color: 'white', fontWeight: '800' },
  bottomNav: { height: 68, borderTopWidth: 1, borderTopColor: C.line, backgroundColor: C.panel, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center', paddingBottom: 5 },
  navItem: { alignItems: 'center', justifyContent: 'center', gap: 3, minWidth: 65 },
  navIcon: { color: C.muted, fontSize: 21, fontWeight: '700' },
  navSelected: { color: '#8992FF' },
  navText: { color: C.muted, fontSize: 10, fontWeight: '700' }
});
