import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { Client, GatewayIntentBits } from 'discord.js';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const app = express();
const port = Number(process.env.API_PORT || 4000);
const allowedChannels = new Set(
  (process.env.ANNOUNCEMENT_CHANNEL_IDS || '')
    .split(',').map(x => x.trim()).filter(Boolean)
);

app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '1mb' }));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.get('/api/servers', async (_req, res) => {
  try {
    const servers = await prisma.server.findMany({ orderBy: { name: 'asc' } });
    res.json(servers);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Could not load servers' });
  }
});

app.get('/api/announcements', async (req, res) => {
  try {
    const { serverId, q, saved } = req.query;
    const where = {};
    if (typeof serverId === 'string' && serverId !== 'all') where.guildId = serverId;
    if (saved === 'true') where.saved = true;
    if (typeof q === 'string' && q.trim()) {
      where.OR = [
        { content: { contains: q.trim(), mode: 'insensitive' } },
        { guildName: { contains: q.trim(), mode: 'insensitive' } },
        { channelName: { contains: q.trim(), mode: 'insensitive' } }
      ];
    }
    const items = await prisma.announcement.findMany({
      where, orderBy: { createdAt: 'desc' }, take: 100
    });
    res.json(items);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Could not load announcements' });
  }
});

app.patch('/api/announcements/:id/save', async (req, res) => {
  try {
    const saved = Boolean(req.body?.saved);
    const item = await prisma.announcement.update({
      where: { id: req.params.id }, data: { saved }
    });
    res.json(item);
  } catch {
    res.status(404).json({ error: 'Announcement not found' });
  }
});

app.listen(port, () => console.log(`Discord News API listening on :${port}`));

if (!process.env.DISCORD_BOT_TOKEN) {
  console.warn('DISCORD_BOT_TOKEN is missing. API is running without the Discord bot.');
} else {
  const bot = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ]
  });

  bot.once('ready', () => {
    console.log(`Discord bot connected as ${bot.user.tag}`);
    console.log(`Watching ${allowedChannels.size} configured channel(s)`);
  });

  bot.on('messageCreate', async message => {
    if (!message.guild || message.author.bot || !allowedChannels.has(message.channelId)) return;
    try {
      const guildName = message.guild.name;
      const channelName = message.channel?.name || 'announcements';
      const image = message.attachments.find(a => a.contentType?.startsWith('image/'));
      const embedImage = message.embeds.find(e => e.image?.url)?.image?.url;
      await prisma.server.upsert({
        where: { id: message.guild.id },
        create: {
          id: message.guild.id,
          name: guildName,
          iconUrl: message.guild.iconURL({ size: 128 })
        },
        update: {
          name: guildName,
          iconUrl: message.guild.iconURL({ size: 128 })
        }
      });
      await prisma.announcement.upsert({
        where: { id: message.id },
        create: {
          id: message.id,
          guildId: message.guild.id,
          guildName,
          channelId: message.channelId,
          channelName,
          author: message.member?.displayName || message.author.username,
          authorAvatar: message.author.displayAvatarURL({ size: 64 }),
          content: message.content || message.embeds.map(e => e.title || e.description || '').filter(Boolean).join('\\n'),
          messageUrl: message.url,
          imageUrl: image?.url || embedImage || null,
          createdAt: message.createdAt
        },
        update: {}
      });
      console.log(`Saved announcement from ${guildName} #${channelName}`);
    } catch (error) {
      console.error('Could not save Discord message:', error);
    }
  });

  bot.login(process.env.DISCORD_BOT_TOKEN).catch(error => {
    console.error('Discord bot login failed:', error.message);
  });
}
