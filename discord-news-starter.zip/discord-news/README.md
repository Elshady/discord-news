# Discord News

Cross-platform Expo / React Native starter app plus a Discord bot backend.

## What is included
- Dark, Discord-inspired mobile news feed for iOS and Android
- Server filter chips and saved announcements
- Announcement cards with image previews and clickable source-message links
- Node.js/Express API and Discord bot
- PostgreSQL schema using Prisma
- Environment-variable configuration; bot token stays on the server

## Architecture
`Discord server -> Discord bot -> Express API + PostgreSQL -> Expo mobile app`

The bot stores messages only from channel IDs explicitly listed in `ANNOUNCEMENT_CHANNEL_IDS`.
It needs access to those channels and the Discord `View Channel` and `Read Message History` permissions.
For message text, enable the **Message Content Intent** for the bot in the Discord Developer Portal.
Do not add a bot to a server without the server owner's/admin's permission.

## 1. Create the Discord bot
1. Create an application at https://discord.com/developers/applications
2. Add a Bot user and copy its token.
3. Enable the Message Content Intent under Bot -> Privileged Gateway Intents.
4. Invite it to your server with `View Channels`, `Read Message History`, and (if needed) `Read Messages/View Channel` access to announcement channels.
5. Copy the IDs of the channels you want to follow (enable Developer Mode in Discord, then right-click a channel -> Copy Channel ID).

## 2. Start the backend
Requirements: Node.js 20+, PostgreSQL.

```bash
cd server
cp .env.example .env
# Edit .env and set DATABASE_URL, DISCORD_BOT_TOKEN, ANNOUNCEMENT_CHANNEL_IDS, API_PORT
npm install
npx prisma generate
npx prisma db push
npm run dev
```

Example `ANNOUNCEMENT_CHANNEL_IDS`:
`123456789012345678,234567890123456789`

The API defaults to `http://localhost:4000`. For a physical phone, set `EXPO_PUBLIC_API_URL` to your computer's LAN IP, e.g. `http://192.168.1.20:4000`.

## 3. Start the mobile app
```bash
cd mobile
npm install
cp .env.example .env
# Set EXPO_PUBLIC_API_URL to your backend address
npx expo start
```
Scan the QR code with Expo Go. For store-ready builds, configure EAS Build:
https://docs.expo.dev/build/introduction/

## API
- `GET /health`
- `GET /api/servers`
- `GET /api/announcements?serverId=<discord-server-id>&q=<search>&saved=true`
- `PATCH /api/announcements/:id/save` with `{ "saved": true }`

## Important production work before public release
This is a runnable starter, not a hosted service or a finished store submission. Before production:
- Add Discord OAuth2 login and bind each user to servers they are authorized to view.
- Add per-user authorization to every API endpoint; current demo API is intended for a trusted private test environment only.
- Add push notification registration and Expo push delivery.
- Add rate limiting, request validation, HTTPS, backups, monitoring, and secret rotation.
- Review Discord Developer Terms, API Terms, and privacy/data-retention requirements.
- Do not expose the backend publicly until authentication and authorization are implemented.
